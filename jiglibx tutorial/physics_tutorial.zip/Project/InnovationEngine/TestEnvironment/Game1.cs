using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Innovation;

namespace TestEnvironment
{
    public class Game1 : Game
    {
        // The IGraphicsDeviceService the engine will use
        GraphicsDeviceManager graphics;

        public Game1()
        {
            // Setup graphics
            graphics = new GraphicsDeviceManager(this);
        }

        protected override void LoadContent()
        {
            // Setup engine. We do this in the load method
            // so that we know graphics will be ready for use
            Engine.SetupEngine(graphics);

            // Create a new Camera
            Camera camera = new Camera();

            // Setup its position and target
            camera.Position = new Vector3(3, 3, 5);
            camera.Target = new Vector3(0, 0, 0);

            // Add it to the service container
            Engine.Services.AddService(typeof(Camera), camera);

            // Setup physics
            Engine.Services.AddService(typeof(Physics), new Physics());

            // Create the plane and make it immovable
            PhysicsActor plane = new PhysicsActor(
                Engine.Content.Load<Model>("Content/ig_plane"),
                new BoxObject(new Vector3(4, .01f, 4)));
            plane.PhysicsObject.Immovable = true;

            // Load the model we will use for our boxes
            Model model = Engine.Content.Load<Model>("Content/ig_box");

            // Create the stack of boxes
            for (int y = 0; y < 3; y++)
                for (int x = 0; x < 3; x++)
                {
                    PhysicsActor act = new PhysicsActor(model, new BoxObject(
                        new Vector3(.5f),
                        new Vector3(-.5f + (x * 0.52f), .5f + (y * 0.52f), -1),
                        Vector3.Zero));

                    act.Scale = new Vector3(.5f);
                }
        }

        bool fired = false;

        protected override void Update(GameTime gameTime)
        {
            // Update the engine and game
            Engine.Update(gameTime);

            if (gameTime.TotalGameTime.TotalSeconds > 2 && !fired)
            {
                PhysicsActor act = new PhysicsActor(
                    Engine.Content.Load<Model>("Content/ig_box"),
                    new BoxObject(new Vector3(1), new Vector3(0, .5f, 1), Vector3.Zero));

                act.Scale = new Vector3(1);
                act.PhysicsObject.Mass = 1000;
                act.PhysicsObject.Velocity = new Vector3(0, 2, -6);

                fired = true;
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);

            // Draw the engine and game
            Engine.Draw(gameTime, ComponentType.All);
        }
    }
}