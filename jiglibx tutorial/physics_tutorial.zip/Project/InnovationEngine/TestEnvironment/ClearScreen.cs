﻿using Innovation;
using Microsoft.Xna.Framework.Graphics;

namespace TestEnvironment
{
    class ClearScreen : Component
    {
        // Override the component's draw method
        public override void Draw()
        {
            // Simply clear the backbuffer to red
            Engine.GraphicsDevice.Clear(Color.Red);
        }
    }
}